import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import GenerateLocationDetailsTable from "../components/GenerateLocationDetailsTable"
export default function LocationsDetails() {
  const LOCATIONINFOURL = 'http://localhost:5129/api/LocalServiceArea?code='
  let totalExpiations = 0
  const navigate = useNavigate()
   // remove : character from the start of the url string then get the year and code result = [location code, year]
  const [locationYearCode, setLocationYearCode] = useState(useParams().id.substring(1).split("+"))
  const [locationData, setLocationData] = useState([])
  const [offencesTable, setOffencesTable] = useState()
  const [locationDetails, setLocationDetails] = useState({
    "localServiceAreaCode": "N/A",
    "localServiceAreaName": "N/A"
  })
  // get location details i.e. area
  useEffect(() => {
    fetch(LOCATIONINFOURL + locationYearCode[0])
    .then((response) => response.json())
    .then((data) => setLocationDetails(data))
    .catch((error) => console.log(error));
  },[locationYearCode])

  // get offence data for location
  useEffect(() => {
    fetch(`http://localhost:5129/api/LocalServiceAreaExpiations?code=${locationDetails.localServiceAreaCode}&year=${locationYearCode[1]}&inclZero=true`)
    .then((response) => response.json())
    .then((data) => setLocationData(data))
    .catch((error) => console.log(error));
  },[locationDetails])
  locationData.forEach(e => totalExpiations += e.count)

  // update the table as different locations and years are chosen 
  useEffect(() => {
    setOffencesTable(<GenerateLocationDetailsTable data={locationData}/>)
  },[locationData])
  

  return (
    <div className="container">
      <div className="row">
        <div className="col-12">
        <button  type="button" className="btn btn-outline-warning btn-lg" onClick={() => navigate(-1)}>Go back</button>
        <br/>
        <br/>
          <ol className="list-group list-group-numbered">
            <li className="list-group-item d-flex justify-content-between align-items-start list-group-item-primary">
              <div className="ms-2 me-auto">
                <div className="fw-bold">Selected Area</div>
                    {locationDetails.localServiceAreaName}
              </div>
            </li>
            <li className="list-group-item d-flex justify-content-between align-items-start list-group-item-success">
              <div className="ms-2 me-auto">
                <div className="fw-bold">Selected Year</div>
                {locationYearCode[1]}
              </div>
            </li>
            <li className="list-group-item d-flex justify-content-between align-items-start list-group-item-info">
              <div className="ms-2 me-auto">
                <div className="fw-bold">Total Expiation Offences</div>
              {totalExpiations}
              </div>
            </li>
          </ol>
          <br/>
          {offencesTable}
        </div>
      </div>
    </div>
  )
}
