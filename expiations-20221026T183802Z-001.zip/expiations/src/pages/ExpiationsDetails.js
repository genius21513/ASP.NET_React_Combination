import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import GenerateExpiationDetailsTable from '../components/GenerateExpiationDetailsTable'
export default function ExpiationsDetails() {
  const navigate = useNavigate()
  const URL = "http://localhost:5129/api/ExpiationCodeYearList?code=";
  const CODEINFOURL = "http://localhost:5129/api/ExpiationOffenceCode?code="
  const [offenceCode, setOffenceCode] = useState(useParams().id.substring(1)) // remove : character from the start of the url string
  const [offenceCodeDes, setOffenceCodeDes] = useState({
    "expiationOffenceCode": "NA",
    "expiationOffenceDescription": "NA",
    "expiationCategory": {
        "expiationOffenceCode": "NA",
        "categoryDescription": "NA",
        "category": "NA",
        "expiationOffenceCodeNavigation": null
    }
})
  const [avalibleYears, setAvalibleYears] = useState([])
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear())
  const [detailsTable, setDetailsTable] = useState()
  // get avalible years
  useEffect( () => {
    // avalible years
     fetch(URL + offenceCode)
      .then((response) => response.json())
      .then((data) => setAvalibleYears(data))
      .catch((error) => console.log(error));
    // code info
     fetch(CODEINFOURL + offenceCode)
      .then((response) => response.json())
      .then((data) => setOffenceCodeDes(data))
      .catch((error) => console.log(error));
  }, [offenceCode]);
  // update details table as year is changed 
  useEffect(() => {
    setDetailsTable(<GenerateExpiationDetailsTable year={selectedYear} code={offenceCode}/>)
  }, [selectedYear, offenceCode])
  return (
    <div className="container">
      <div className="row">
        <div className="col-12">
        <button  type="button" className="btn btn-outline-warning btn-lg" onClick={() => navigate(-1)}>Go back</button>
        <br/>

        <br/>
          <ol className="list-group list-group-numbered">
            <li className="list-group-item d-flex justify-content-between align-items-start list-group-item-primary">
              <div className="ms-2 me-auto">
                <div className="fw-bold">Expiation Offence Code</div>
                {offenceCodeDes.expiationOffenceCode}
              </div>
            </li>
            <li className="list-group-item d-flex justify-content-between align-items-start list-group-item-success">
              <div className="ms-2 me-auto">
                <div className="fw-bold">Category Description</div>
                {offenceCodeDes.expiationCategory.categoryDescription}
              </div>
            </li>
            <li className="list-group-item d-flex justify-content-between align-items-start list-group-item-info">
              <div className="ms-2 me-auto">
                <div className="fw-bold">Expiation Offence Description</div>
                {offenceCodeDes.expiationOffenceDescription}
              </div>
            </li>
          </ol>
          <nav className="navbar navbar-expand-lg bg-light">
            <select className="form-select" aria-label="Default select example" onChange={(e) => setSelectedYear(e.target.value)} >
              {avalibleYears.map((year, index) => {
                if (index - 1 === undefined) return <option value={year}selected>{year}</option>
                if (index -1 != undefined) return <option value={year}>{year}</option>
              })}
            </select>
          </nav>
            {detailsTable}
        </div>
      </div>
    </div>
  );
}
