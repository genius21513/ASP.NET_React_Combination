import React, { useState, useEffect } from "react";
import GenerateExpiationTable from "../components/GenerateExpiationTable";
export default function Expiations() {
  const URL = "http://localhost:5129/api/ExpiationOffenceCodeList?searchText=";
  const [ExpiationOffenceCodeList, setExpiationOffenceCodeList] = useState([]); // may be filered by search
  const [searchHelpers, setSearchHelpers] = useState([]); // used to maintain search codes showing in the input box
  const [table, setTable] = useState();
  const [searchText, setSearchText] = useState("");
  const [executeSearch, setExecuteSearch] = useState("")

  useEffect(() => {
    console.log(executeSearch)
    fetch(URL + searchText)
      .then((response) => response.json())
      .then((data) => setExpiationOffenceCodeList(data))
      .catch((error) => console.log(error));
  }, [executeSearch]);

  useEffect(() => {
    fetch(URL + searchText)
      .then((response) => response.json())
      .then((data) => setSearchHelpers(data))
      .catch((error) => console.log(error));
  }, []);

  useEffect(() => {
    setTable(
      <GenerateExpiationTable
        data={ExpiationOffenceCodeList}
        columnHeadings={[
          "expiationOffenceCode",
          "expiationOffenceDescription",
          "Details",
        ]}
      />
    );
  }, [ExpiationOffenceCodeList]);

  return (
    <div className="container">

      <div className="row">
        <div className="col-12">
        <h1>Expiations</h1>
          <nav className="navbar navbar-expand-lg bg-light">
            <div className="container-fluid">
              <form className="d-flex" role="search">
              <div className="input-group">
                      <input
                      list="offence-codes"
                      className="form-control me-2"
                      type="search"
                      placeholder="Search for expiation"
                      aria-label="Search"
                      onChange={(e) => setSearchText(e.target.value)}
                    />
                    <datalist id="offence-codes">
                      {searchHelpers.map((codes) => (
                        <option value={codes.expiationOffenceCode} />
                      ))}
                    </datalist>  <span className="input-group-text">
                    Count: {ExpiationOffenceCodeList.length}
                  </span>
                  <a className="btn btn-outline-success" onClick={() => setExecuteSearch(searchText)}>Search</a>
                </div>
              </form>
            </div>
          </nav>
        </div>
      </div>
      {table}
    </div>
  );
}
