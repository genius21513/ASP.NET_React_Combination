import React, {useState, useEffect} from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Locations() {
  const YEARSURL = 'http://localhost:5129/api/LSAYearList'
  const LOCATIONSURL =  'http://localhost:5129/api/LocalServiceAreaList?year='
  const navigate = useNavigate()
  const [objectKey, setObjectKey] = useState([])
  const [avalibleYears, setAvalibleYears] = useState([new Date().getFullYear()])
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear())
  const [locationData, setLocationData] = useState([{
    "localServiceArea": "N/A",
    "localServiceAreaCode": "N/A",
    "count": null
}])
  useEffect( () => {
    // avalible years
     fetch(YEARSURL)
      .then((response) => response.json())
      .then((data) => setAvalibleYears(data))
      .catch((error) => console.log(error));
  },[YEARSURL])

  useEffect(() =>{
    fetch(LOCATIONSURL + selectedYear)
    .then((response) => response.json())
    .then((data) => setLocationData(data))
    .catch((error) => console.log(error));
    setObjectKey(Object.keys(locationData[0]))
  },[selectedYear])
  return (
    <div className="container">
      <div className="row">
        <div className="col-12">
        <h1>Locations</h1>
          <nav className="navbar navbar-expand-lg bg-light">
            <div className="container-fluid">
              <form className="d-flex" role="search">
                <div className="input-group">
                <select className="form-select" aria-label="Default select example" onChange={(e) => setSelectedYear(e.target.value)}>
                  {avalibleYears.map((todaysYear, index) => {
                    if (index -1 === undefined) return <option value={todaysYear} selected>{todaysYear}</option>
                    if (index -1 != undefined) return <option value={todaysYear}>{todaysYear}</option>
                  })}
                </select>
                  <span className="input-group-text">Count: {locationData.length}</span>
                </div>
              </form>
            </div>
          </nav>
          <table className="table table-striped table-hover">
          <thead>
              <tr>
              {objectKey.map((key) => (
                <th scope="col">{key}</th>
              ))}
              <th>Details</th>
              </tr>
            </thead>
            <tbody>
              {locationData.map((location) => {
                if(location.count > 0) return (
                  (
                <tr  onClick={() =>
              navigate(`./Details:${location.localServiceAreaCode}+${selectedYear}`)
            }>
                  <td>{location.localServiceAreaCode}</td>
                  <td>{location.localServiceArea}</td>
                  <td>{location.count}</td>
                  <td>              <Link
                className="button btn btn-outline-info btn-lg"
                to={`Details:${location.localServiceAreaCode}+${selectedYear}`}
              >
                SHOW DETAILS
              </Link></td>
                </tr>
              ))})}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
