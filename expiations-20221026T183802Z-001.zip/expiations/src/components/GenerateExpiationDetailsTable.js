import React, { useState, useEffect } from "react";

export default function GenerateExpiationDetailsTable({year, code},props) {
  const [monthlyData, setMonthlyData] = useState([]) // stores all data
  // stores yearly total
  let total = 0 
  // stores monthly totals
  let monthlyTotal = {
    January : 0, 
    February : 0, 
    March : 0, 
    April : 0, 
    May : 0, 
    June : 0, 
    July : 0, 
    August : 0, 
    September : 0, 
    October : 0, 
    November : 0, 
    December : 0
  }
  // fetch data
  useEffect(() => {
    const URL = `http://localhost:5129/api/ExpiationCodeSummary?code=${code}&year=${year}`
    fetch(URL)
      .then((response) => response.json())
      .then((data) => setMonthlyData(data))
      .catch((error) => console.log(error));
  }, [code, year]);
  
  // get totals
  monthlyData.forEach((month) => {
    month.noticeDetailList.forEach((offence) => {
      total += offence.count
      monthlyTotal[month.monthName] += offence.count
    })
  })


  const colours = {
  "COURTS RELIEF STATUS": "table-primary text-dark fs-4",
  "EXPIATED": "bg-danger text-white fs-4",
  "COURTS ENFORCEMENT (pending or enforced)": "bg-secondary text-dark fs-4",
  "WITHDRAWN": "bg-success text-white fs-4",
  "ISSUED OR CAUTIONED": "table-warning text-dark fs-4",
  "MULTIPLE OFFENCES - PROCESSED": "bg-info text-white fs-4",
  "INVALID": "bg-light text-dark fs-4",
  "SUSPENDED FOR ENQUIRY": "bg-white text-dark fs-4",
}

  return(
    <>

    <table className="table table-secondary">
  <thead>
    <tr>
      <th scope="col">Month</th>
      <th scope="col">Description</th>
      <th scope="col">Count</th>
    </tr>
  </thead>
  <tbody>
  {monthlyData.map((month) => (
        
        <>
        <tr>
          <th colspan="3">{month.monthName}</th>
        </tr>
        
        
          {month.noticeDetailList.map(offence => (
            <tr className="text-end">
            <td colspan="2" className={colours[offence.noticeStatusDescription]}>{offence.noticeStatusDescription}</td>
            <td className={colours[offence.noticeStatusDescription]}>{offence.count}</td>
            </tr>
          ))}
        
        <td className="badge bg-primary text-wrap" style={{width: "20rem", fontSize: "1.5rem"}}>{month.monthName} Sub-Total: {monthlyTotal[month.monthName]}</td>
        </>
        ))}
  </tbody>
</table>
    <ol className="list-group list-group-numbered">
      <li className="list-group-item d-flex justify-content-between align-items-start list-group-item-primary">
        <div className="ms-2 me-auto">
          <div className="fw-bold">{year} TOTAL: {total}</div>
        </div>
      </li>
    </ol>
    </>

  );
}
