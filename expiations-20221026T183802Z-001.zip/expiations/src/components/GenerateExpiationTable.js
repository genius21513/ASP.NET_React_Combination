import React from "react";
import { Link, useNavigate } from "react-router-dom";

export default function GenerateExpiationTable({ data, columnHeadings },props) {
  const navigate = useNavigate();
  return (
    <table className="table table-striped table-hover ">
      <thead>
        <tr>
          {columnHeadings.map((heading) => (
            <th>{heading}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {data.map((offence) => (
          <tr
            onClick={() =>
              navigate(`./Details:${offence.expiationOffenceCode}`)
            }
          >
            <td>{offence.expiationOffenceCode}</td>
            <td>{offence.expiationOffenceDescription}</td>
            <td className="text-end">
              <Link
                className="button btn btn-outline-info btn-lg"
                to={`Details:${offence.expiationOffenceCode}`}
              >
                SHOW DETAILS
              </Link>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
