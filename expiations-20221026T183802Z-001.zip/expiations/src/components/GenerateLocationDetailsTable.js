import React from 'react'

export default function GenerateLocationDetailsTable({data}, props) {
    console.log(data)
  return (
    <table className="table table-danger table-striped table-hover">
    <thead>
    <tr>
    <th scope="col">expiation Offence Code</th>
      <th scope="col">expiation Offence Description</th>
      <th scope="col">count</th>

    </tr>
  </thead>
  <tbody>
  {data.map((offence) => (
    <tr>
      <td>{offence.expiationOffenceCode}</td>
      <td>{offence.expiationOffenceDescription}</td>
      <td>{offence.count}</td>
    </tr>
  ))}
    
  </tbody>
    </table>
  )
}
