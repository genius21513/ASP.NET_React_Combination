﻿namespace SAExpiationsA2.Models.Custom
{
    public class NoticeStatusDetail
    {
        public string NoticeStatusDescription { get; set; }
        public int MonthNo { get; set; }
        public string ClassName { get; set; }
        public int Count { get; set; } = 0;
    }
}
