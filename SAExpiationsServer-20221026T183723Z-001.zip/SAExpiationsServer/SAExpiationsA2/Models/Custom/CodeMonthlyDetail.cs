﻿namespace SAExpiationsA2.Models.Custom
{
    public class CodeMonthlyDetail
    {
        public int MonthNo { get; set; }
        public string MonthName { get; set; }
        public List<NoticeStatusDetail> NoticeDetailList { get; set; }

        public CodeMonthlyDetail()
        {
            NoticeDetailList = new List<NoticeStatusDetail>();  
        }
    }
}
