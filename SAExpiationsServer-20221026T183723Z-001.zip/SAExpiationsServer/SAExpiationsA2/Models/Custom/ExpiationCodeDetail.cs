﻿namespace SAExpiationsA2.Models.Custom
{
    public class ExpiationCodeDetail
    {
        public string ExpiationOffenceCode { get; set; }
        public string ExpiationOffenceDescription { get; set; }
        public ExpiationCategory ExpiationCategory { get; set; }
        public int Count { get; set; } = 0;
    }
}
