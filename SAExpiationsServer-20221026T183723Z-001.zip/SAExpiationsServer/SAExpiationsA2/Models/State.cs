﻿using System;
using System.Collections.Generic;

namespace SAExpiationsA2.Models
{
    public partial class State
    {
        public string State1 { get; set; } = null!;
        public string StateDescription { get; set; } = null!;
    }
}
