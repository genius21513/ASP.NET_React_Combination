﻿using System;
using System.Collections.Generic;

namespace SAExpiationsA2.Models
{
    public partial class LocalServiceArea
    {
        public string LocalServiceAreaCode { get; set; } = null!;
        public string LocalServiceAreaName { get; set; }
    }
}
