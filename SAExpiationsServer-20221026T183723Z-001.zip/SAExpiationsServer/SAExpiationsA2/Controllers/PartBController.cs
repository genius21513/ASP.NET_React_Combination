﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SAExpiationsA2.Data;
using SAExpiationsA2.Models;
using SAExpiationsA2.Models.Custom;
using System.ComponentModel.DataAnnotations;

namespace SAExpiationsA2.Controllers
{
    [ApiController]
    public class PartBController : ControllerBase
    {
        private readonly ExpiationsContext _context;

        public PartBController(ExpiationsContext context)
        {
            _context = context;
        }


        [HttpGet]
        [Route("api/LSAYearList")]
        // GET: api/LSAYearList
        public async Task<ActionResult<IEnumerable<int>>> GetLSAYearList()
        {
            var YearList = await _context.Expiations
                .Select(e => e.IssueDate.Year)
                .Distinct()
                .OrderByDescending(e => e)
                .ToListAsync();

            if (YearList.Count == 0) { return NoContent(); }
            return YearList;
        }


        [HttpGet]
        [Route("api/LocalServiceAreaList")]
        public async Task<ActionResult<IEnumerable<LocalServiceAreaDetail>>> GetLocalServiceAreaList(int? year)
        {
            var LSAList = _context.LocalServiceAreas
                .Select(lsa => new LocalServiceAreaDetail
                {
                    LocalServiceArea = lsa.LocalServiceAreaName,
                    LocalServiceAreaCode = lsa.LocalServiceAreaCode,
                    Count = _context.Expiations
                    .Where(e => e.LocalServiceAreaCode == lsa.LocalServiceAreaCode)
                    .Where(e => !year.HasValue || e.IssueDate.Year == year.Value)
                    .Count()
                });
            return await LSAList.ToListAsync();
        }


        [HttpGet]
        [Route("api/LocalServiceArea")]
        // GET: api/LocalServiceArea?code=A
        public async Task<ActionResult<LocalServiceArea>> GetLocalServiceArea([Required] string code)
        {
            if (string.IsNullOrWhiteSpace(code))
            {
                return BadRequest();
            }

            var LSA = await _context.LocalServiceAreas
                .Where(lsa => lsa.LocalServiceAreaCode == code)
                .FirstOrDefaultAsync();

            if (LSA == null)
            {
                return NotFound();
            }

            return LSA;
        }

        [HttpGet]
        [Route("api/LocalServiceAreaExpiations")]
        // GET: api/LocalServiceArea?code=A&year=2022
        public async Task<ActionResult<IEnumerable<ExpiationCodeDetail>>> GetLSAExpiations([Required] string code, [Required] int year, bool inclZero = true)
        {
            if (string.IsNullOrWhiteSpace(code) || year == 0)
            {
                return BadRequest();
            }

            var codeQuery = await _context.ExpiationOffences
                .Where(eo => !string.IsNullOrWhiteSpace(eo.ExpiationOffenceCode))
                .OrderBy(eo => eo.ExpiationOffenceCode)
                .Select(eo => new ExpiationCodeDetail
                {
                    ExpiationCategory = eo.ExpiationCategory,
                    ExpiationOffenceCode = eo.ExpiationOffenceCode,
                    ExpiationOffenceDescription = eo.ExpiationOffenceDescription,
                    Count = _context.Expiations
                                        .Where(e => e.LocalServiceAreaCode == code
                                        && e.IssueDate.Year == year
                                        && e.ExpiationOffenceCode == eo.ExpiationOffenceCode)
                                        .Count(),
                }).ToListAsync();

            if (!inclZero)
            {
                codeQuery = codeQuery.Where(cq => cq.Count > 0).ToList();
            }

            return codeQuery;
        }
    }
}
