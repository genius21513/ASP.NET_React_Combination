﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SAExpiationsA2.Data;
using SAExpiationsA2.Models;
using SAExpiationsA2.Models.Custom;
using System.ComponentModel.DataAnnotations;

namespace SAExpiationsA2.Controllers
{
    [ApiController]
    public class PartAController : ControllerBase
    {
        private readonly ExpiationsContext _context;

        // set IncludeClassNames to true if want to use for styling equivalent rows
        // NB: could slow down queries so leave false until ready to style
        private readonly bool IncludeClassNames = true;

        public PartAController(ExpiationsContext context)
        {
            _context = context;
        }

        [HttpGet]
        [Route("api/ExpiationOffenceCodeList")]
        // GET: api/ExpiationOffenceCodeList?codeSearch=A&descSearch=Bus
        public async Task<ActionResult<IEnumerable<ExpiationOffence>>> GetExpiationOffences(string? searchText = null)
        {
            var CodeList = _context.ExpiationOffences
                .OrderBy(eo => eo.ExpiationOffenceCode)
                .Where(eo => !string.IsNullOrWhiteSpace(eo.ExpiationOffenceCode))
                .Select(eo => new ExpiationOffence
                {
                    ExpiationOffenceCode = eo.ExpiationOffenceCode,
                    ExpiationOffenceDescription = eo.ExpiationOffenceDescription,
                    ExpiationCategory = eo.ExpiationCategory,
                });

            // Filter for expiation codes that start with code being searched
            if (!string.IsNullOrWhiteSpace(searchText))
            {
                // Note: this type of combined search with sorting will slow the query down significantly
                CodeList = CodeList.Where(eo => eo.ExpiationOffenceCode.StartsWith(searchText) || eo.ExpiationOffenceDescription.Contains(searchText))
                    .OrderBy(eo => eo.ExpiationOffenceCode.StartsWith(searchText) ? 0 : 1)
                    .ThenBy(eo => eo.ExpiationOffenceCode)
                    .ThenBy(eo => eo.ExpiationOffenceDescription.Contains(searchText));
            }
            return await CodeList.ToListAsync();
        }

        [HttpGet]
        [Route("api/ExpiationOffenceCode")]
        // GET: api/ExpiationOffenceCode?code=A001
        public async Task<ActionResult<ExpiationOffence>> GetExpiationOffenceCode([Required] string code)
        {
            if (String.IsNullOrWhiteSpace(code))
            {
                return BadRequest();
            }

            var Code = await _context.ExpiationOffences
                .Where(eo => eo.ExpiationOffenceCode == code)
                .Select(eo => new ExpiationOffence
                {
                    ExpiationOffenceCode = eo.ExpiationOffenceCode,
                    ExpiationOffenceDescription = eo.ExpiationOffenceDescription,
                    ExpiationCategory = eo.ExpiationCategory,
                }).FirstOrDefaultAsync();

            if (Code == null)
            {
                return NotFound();
            }

            return Code;
        }

        [HttpGet]
        [Route("api/ExpiationCodeYearList")]
        // GET: api/ExpiationCodeYearList?code=A001
        public async Task<ActionResult<IEnumerable<int>>> GetExpiationCodeYearList([Required] string code)
        {
            if (string.IsNullOrWhiteSpace(code))
            {
                return BadRequest();
            }
            if (!ExpiationOffenceExists(code))
            {
                return NotFound();
            }

            var YearList = await _context.Expiations
                .Where(e => e.ExpiationOffenceCode == code)
                .Select(e => e.IssueDate.Year)
                .Distinct()
                .OrderByDescending(e => e)
                .ToListAsync();

            if (YearList.Count == 0) { return NoContent(); }
            return YearList;
        }

        [HttpGet]
        [Route("api/ExpiationCodeSummary")]
        // GET: api/ExpiationCodeSummary?code=A001&year=2022
        public async Task<ActionResult<IEnumerable<CodeMonthlyDetail>>> GetExpiationCodeSummary([Required] string code, [Required] int year)
        {
            if (string.IsNullOrWhiteSpace(code) || year == 0)
            {
                return BadRequest();
            }
            if (!ExpiationOffenceExists(code))
            {
                return NotFound();
            }

            var statusQuery = await _context.Expiations
                .Where(e => e.ExpiationOffenceCode == code)
                .Where(e => e.IssueDate.Year == year)
                .GroupBy(e => new { e.IssueDate.Month, e.NoticeStatusDesc })
                .OrderBy(e => e.Key.NoticeStatusDesc)
                .Select(e => new NoticeStatusDetail
                {
                    NoticeStatusDescription = e.Key.NoticeStatusDesc,
                    MonthNo = e.Key.Month,
                    Count = e.Count()
                }).ToListAsync();

            // get array of month names (returns 13 values to account for zero index)
            var MonthNames = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.MonthGenitiveNames;

            var NoticeStatusList = new string[0];
            if (IncludeClassNames)
            {
                NoticeStatusList = _context.Expiations
                    .Select(e => e.NoticeStatusDesc)
                    .Distinct()
                    .OrderBy(nsd => nsd)
                    .ToArray();
            }

            var FinalData = MonthNames
                .Where((mn, index) => index < 12) // remove 13th item from MonthNames
                .Select((mn, index) => new CodeMonthlyDetail
                {
                    MonthNo = index + 1,
                    MonthName = mn,
                    NoticeDetailList = statusQuery
                    .Where(sq => sq.MonthNo == index + 1)
                    .Select(sq =>
                    {
                        // set IncludeClassNames to true if want to use for styling equivalent rows
                        if (IncludeClassNames)
                        {
                            sq.ClassName = "NSD_" + (NoticeStatusList.Select((val, index) => new { val, index })
                                            .Where(nsl => nsl.val == sq.NoticeStatusDescription)
                                            .Select(nsl => nsl.index)
                                            .FirstOrDefault());
                        }
                        return sq;
                    })
                    .ToList()
                }).ToList();

            return FinalData;
        }


        private bool ExpiationOffenceExists(string code)
        {
            return _context.ExpiationOffences.Any(e => e.ExpiationOffenceCode == code);
        }

    }
}
