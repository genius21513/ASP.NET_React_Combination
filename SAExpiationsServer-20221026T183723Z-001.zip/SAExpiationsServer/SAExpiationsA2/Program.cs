using Microsoft.EntityFrameworkCore;
using SAExpiationsA2.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Add the Expiations DB Context
builder.Services.AddDbContext<ExpiationsContext>(options =>
options.UseSqlServer(builder.Configuration.GetConnectionString("ExpiationsContext") ??
throw new InvalidOperationException("Connection string for Expiation Context not found!")));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors(b =>
{
    b.AllowAnyMethod();
    b.AllowAnyOrigin();
    b.AllowAnyHeader();
});

app.UseAuthorization();

app.MapControllers();

app.Run();
