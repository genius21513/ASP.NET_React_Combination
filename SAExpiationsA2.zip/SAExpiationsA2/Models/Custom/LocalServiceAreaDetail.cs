﻿namespace SAExpiationsA2.Models.Custom
{
    public class LocalServiceAreaDetail
    {
        public string LocalServiceArea { get; set; }
        public string LocalServiceAreaCode { get; set; }
        public int Count { get; set; }
    }
}
