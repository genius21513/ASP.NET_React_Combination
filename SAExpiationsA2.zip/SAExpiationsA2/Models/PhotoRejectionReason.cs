﻿using System;
using System.Collections.Generic;

namespace SAExpiationsA2.Models
{
    public partial class PhotoRejectionReason
    {
        public int PhotoRejectionCode { get; set; }
        public string? PhotoRejecetionReason { get; set; }
    }
}
