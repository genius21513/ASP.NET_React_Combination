﻿using System;
using System.Collections.Generic;

namespace SAExpiationsA2.Models
{
    public partial class ExpiationOffence
    {
        public string ExpiationOffenceCode { get; set; } = null!;
        public string ExpiationOffenceDescription { get; set; } = null!;

        public virtual ExpiationCategory ExpiationCategory { get; set; } = null!;
    }
}
